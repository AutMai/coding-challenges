﻿namespace ccc_35_classic_compiler; 

public class Variable {
    public string Name { get; init; }
    public object Value { get; set; }
}