﻿namespace ccc_35_school_trick_or_trade; 

public class Economist {
    public int Id { get; set; }
    public List<Sweet> Sweets { get; set; }
}