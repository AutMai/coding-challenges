﻿namespace ccc_35_school_trick_or_trade; 

public class Sweet {
    public int Value { get; set; }
    public Economist Economist { get; set; }
}