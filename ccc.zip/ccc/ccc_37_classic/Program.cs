﻿using CodingHelper;

var r = new InputReader();

r.ReadZipFile("files/level1.zip", " ");

foreach (var l in r.GetInputs()) {
}