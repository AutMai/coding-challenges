﻿using CodingHelper;

var r = new InputReader();

r.ReadZipFile("files/level2.zip", " ");


foreach (var l in r.GetInputs()) {
    l.SetOutput();
    var count = 0;
    while (l.HasNotEnded()) {
        var line = l.Read();
        // count 0 in line
        foreach (var c in line) {
            if (c == 'O') {
                count++;
            }
        }
    }

    Console.WriteLine(count);
}